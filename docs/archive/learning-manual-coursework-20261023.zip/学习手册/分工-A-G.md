# A–G 分工与 API 清单

本清单用于七位同学分发阅读与准备答辩。每个接口按“HTTP方法＋路径”唯一归属；所有路径均写出完整 `/api/v1` 前缀。共55个业务接口，另有2个运行检查接口归A，合计57个。

| 同学 | 主讲范围 | 业务接口数 | 主要阅读 |
| --- | --- | --- | --- |
| A | 账号与登录 | 9 | [04章](04-M1账号与登录.md) |
| B | 在线鉴权 | 3 | [05章](05-M6在线鉴权.md) |
| C | 资源管理 | 11 | [06章](06-M3资源管理.md) |
| D | 角色与授权 | 11 | [07章](07-M4角色与授权.md) |
| E | 管理员与管理范围 | 6 | [08章](08-M5管理员与管理范围.md) |
| F | 组织与 HR | 9 | [09章](09-M2组织与HR事件.md) |
| G | 批量、OA 与审计 | 6 | [10章](10-批量授权与OA审批.md)、[12章](12-安全机制.md) |

## 共同准备

所有人先读01–03章，掌握请求链路、统一响应和数据库关系。每人对自己的接口都应能说明用途、调用者与权限、参数、处理流程、涉及表、返回结果和常见错误，并对照Controller→Service→Repository阅读。

11章按自己接口涉及的事务与版本规则选读；12章中数据签名和服务请求认证由使用这些机制的同学共同理解，审计查询接口归G；13章初始化与兜底恢复作为共同了解内容。14章阅读自己负责功能的页面；15–16章按自己模块选择测试与练习。

接口数量不代表难度：B接口少但承担核心权限计算；D、F需特别理解业务规则。章节号保留，A–G表示人员分工。

## A 同学

**账号与登录**，业务接口 9 个。主要阅读 [04章](04-M1账号与登录.md)。

重点：身份验证、JWT、密码与账号状态；附带启动检查。

| API | 用途 |
| --- | --- |
| `POST /api/v1/auth/login` | 密码登录 |
| `POST /api/v1/auth/sms/send` | 发送设密验证码 |
| `POST /api/v1/auth/password/initialize` | 首次设置密码 |
| `POST /api/v1/auth/password/reset` | 重置密码 |
| `POST /api/v1/auth/logout` | 退出当前登录 |
| `GET /api/v1/users` | 查询用户列表 |
| `GET /api/v1/users/{userId}` | 查询用户详情 |
| `POST /api/v1/users/temporary` | 创建临时账号 |
| `PATCH /api/v1/users/{userId}/status` | 修改临时账号状态 |

启动检查也由 A 负责（不计入业务接口数）：

| API | 用途 |
| --- | --- |
| `GET /api/v1/system/ping` | 检查应用状态 |
| `GET /api/v1/system/database` | 检查数据库状态 |

源码：[SystemController.java](../backend/src/main/java/com/whatname/iam/controller/system/SystemController.java)、[SystemService.java](../backend/src/main/java/com/whatname/iam/service/system/SystemService.java)。

## B 同学

**在线鉴权**，业务接口 3 个。主要阅读 [05章](05-M6在线鉴权.md)。

重点：用户→角色→菜单→API 的权限计算、实时撤权及拒绝原因。

| API | 用途 |
| --- | --- |
| `GET /api/v1/auth/menus` | 查询自己的应用菜单 |
| `POST /api/v1/auth/check` | 判断用户能否访问业务 API |
| `GET /api/v1/users/{userId}/permissions` | 管理员查看用户菜单权限 |

## C 同学

**资源管理**，业务接口 11 个。主要阅读 [06章](06-M3资源管理.md)。

重点：应用、菜单、API 及关联关系，写入校验与版本冲突。

| API | 用途 |
| --- | --- |
| `GET /api/v1/applications` | 查询应用列表 |
| `POST /api/v1/applications` | 新建应用 |
| `PATCH /api/v1/applications/{appId}` | 修改应用 |
| `GET /api/v1/applications/{appId}/menus` | 查询应用资源菜单 |
| `POST /api/v1/applications/{appId}/menus` | 新建菜单或权限单元 |
| `PATCH /api/v1/menus/{menuId}` | 修改菜单 |
| `GET /api/v1/applications/{appId}/apis` | 查询应用 API 资源 |
| `POST /api/v1/applications/{appId}/apis` | 登记 API 资源 |
| `PATCH /api/v1/apis/{apiId}` | 修改 API 名称或状态 |
| `GET /api/v1/menus/{menuId}/apis` | 查询菜单关联的 API |
| `PUT /api/v1/menus/{menuId}/apis` | 全量替换菜单 API 关联 |

## D 同学

**角色与授权**，业务接口 11 个。主要阅读 [07章](07-M4角色与授权.md)。

重点：角色定义与授予的区别、授权来源、回收与授权历史。

| API | 用途 |
| --- | --- |
| `GET /api/v1/roles` | 查询角色列表 |
| `POST /api/v1/roles` | 新建普通角色 |
| `GET /api/v1/roles/{roleId}` | 查询角色详情 |
| `PATCH /api/v1/roles/{roleId}` | 修改角色名称或状态 |
| `GET /api/v1/roles/{roleId}/menus` | 查询角色菜单配置 |
| `PUT /api/v1/roles/{roleId}/menus` | 全量替换角色菜单 |
| `GET /api/v1/users/{userId}/roles` | 查询用户有效角色及授权版本 |
| `GET /api/v1/users/{userId}/roles/{roleId}/sources` | 查询角色授权来源 |
| `POST /api/v1/grants/user-roles` | 授予用户角色 |
| `POST /api/v1/grants/user-roles/revoke` | 回收指定授权来源 |
| `GET /api/v1/grants/history` | 查询授权历史 |

## E 同学

**管理员与管理范围**，业务接口 6 个。主要阅读 [08章](08-M5管理员与管理范围.md)。

重点：任命、等级、管理范围、一级管理员直接配置可授权清单。

| API | 用途 |
| --- | --- |
| `GET /api/v1/admins` | 查询管理员任命列表 |
| `POST /api/v1/admins/appointments` | 任命管理员 |
| `POST /api/v1/admins/{userId}/revoke` | 撤销管理员任命 |
| `GET /api/v1/admins/me/scope` | 查询本人管理范围 |
| `GET /api/v1/admins/{userId}/delegable-roles` | 查询可授权角色清单 |
| `PUT /api/v1/admins/{userId}/delegable-roles` | 替换下级可授权角色清单 |

## F 同学

**组织与 HR**，业务接口 9 个。主要阅读 [09章](09-M2组织与HR事件.md)。

重点：组织变化对账号和权限的影响、事件去重、版本顺序与事务。

| API | 用途 |
| --- | --- |
| `PUT /api/v1/integrations/hr/employees/{sgNo}` | 同步员工资料与状态 |
| `POST /api/v1/integrations/hr/transfers` | 处理员工调岗 |
| `POST /api/v1/integrations/hr/terminations` | 处理员工离职 |
| `PUT /api/v1/integrations/hr/departments/{deptCode}` | 同步部门 |
| `POST /api/v1/integrations/hr/merges` | 合并部门 |
| `GET /api/v1/departments` | 查询可见部门结构 |
| `GET /api/v1/departments/{deptId}/users` | 查询部门人员 |
| `POST /api/v1/departments/{deptId}/freeze` | 冻结部门 |
| `POST /api/v1/departments/{deptId}/unfreeze` | 解除部门冻结 |

## G 同学

**批量、OA 与审计**，业务接口 6 个。主要阅读 [第10章](10-批量授权与OA审批.md)和[第12章的12.5审计、12.6服务请求认证](12-安全机制.md)。

重点：最多100人同步处理、逐人事务及部分失败；OA审批事件去重和受控授权；日志查询、审计详情与封印验证。

| API | 用途 |
| --- | --- |
| `POST /api/v1/grants/user-roles/batch` | 同步批量授予或回收角色 |
| `POST /api/v1/integrations/oa/decisions` | 接收 OA 审批结果 |
| `GET /api/v1/audit/operations` | 查询操作日志 |
| `GET /api/v1/audit/authorizations` | 查询鉴权日志 |
| `GET /api/v1/audit/logins` | 查询登录日志 |
| `GET /api/v1/audit/evidence/{eventId}` | 查询审计详情 |

源码入口：[BatchController.java](../backend/src/main/java/com/whatname/iam/controller/grant/BatchController.java)、[OaController.java](../backend/src/main/java/com/whatname/iam/controller/oa/OaController.java)、[AuditController.java](../backend/src/main/java/com/whatname/iam/controller/audit/AuditController.java)。沿入口阅读对应 Service。

边界：D主讲单人授权与授权历史，G主讲批量编排及OA接入；B主讲权限判断，G主讲判断日志如何查询。G应理解复用关系，但不重复主讲D、B的接口。
