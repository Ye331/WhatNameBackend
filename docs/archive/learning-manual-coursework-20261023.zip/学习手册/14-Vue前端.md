> 当前简化范围见 [课程作业范围](../backend/docs/COURSEWORK_SCOPE.md)。旧版完整机制已留档；批量同步、HR/OA 单事务、一级直接配置清单、基础鉴权日志为当前口径。超级用户初始化与紧急权限恢复仍保留。

# 第 14 课：Vue 前端

> 目标：看懂管理控制台的结构：登录、会话保存、按权限显示菜单和按钮、调用后端接口、处理错误。最重要的一点：理解"前端只决定显示什么，真正的权限检查在后端"。
>
> 本课涉及的源码（`frontend/src/` 下）：
> - [main.js](../frontend/src/main.js)、[App.vue](../frontend/src/App.vue)：入口和登录页
> - [session.js](../frontend/src/session.js)：会话、令牌、菜单
> - [api/client.js](../frontend/src/api/client.js)：所有 HTTP 请求的统一出口
> - [access.js](../frontend/src/access.js)：按权限显示页面和按钮
> - [views/ConsoleView.vue](../frontend/src/views/ConsoleView.vue)：控制台框架
> - [composables/useList.js](../frontend/src/composables/useList.js)：列表加载
> - [views/RolesView.vue](../frontend/src/views/RolesView.vue)：一个完整页面的例子
> - [vite.config.js](../frontend/vite.config.js)
>
> 前端约 4100 行，比后端少很多。本课讲清结构和关键机制，具体页面可以照着同样的模式自己读。

---

## 14.1 运行前端

```sh
cd frontend
npm ci              # 按 package-lock.json 安装依赖
npm run dev         # 连接真实后端（需要后端已启动）
npm run dev:mock    # 使用本地模拟数据，不需要后端
```

**推荐先用 `npm run dev:mock`**：不需要数据库和后端，直接在浏览器里把每个页面点一遍。模拟账号 `admin / 123456`，验证码 `123456`（只用于本地模拟，见 [frontend/README.md](../frontend/README.md)）。

| 命令 | 作用 |
| --- | --- |
| `npm run dev` | 开发服务器，`/api` 请求转发到后端 |
| `npm run dev:mock` | 开发服务器 + 模拟 API |
| `npm run build` | 打包到 `dist` 目录，用于部署 |
| `npm test` | 运行 Playwright 页面测试 |

### Vite 和代理

[vite.config.js](../frontend/vite.config.js)：

```js
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  return {
    plugins: [vue(), ...(mode === 'mock' ? [mockApi()] : [])],      // mock 模式加载模拟 API 插件
    server: {
      proxy: mode === 'mock' ? {} : {
        '/api': { target: env.API_PROXY_TARGET || 'http://127.0.0.1:8080', changeOrigin: true },
      },
    },
  }
})
```

**Vite** 是前端的开发服务器和打包工具。

**代理**：前端页面运行在 `http://localhost:5173`，后端在 `http://127.0.0.1:8080`。浏览器的**同源策略**默认禁止页面向不同的地址（协议、域名或端口不同）发请求。代理的做法是：浏览器向 5173 发 `/api/...` 请求，Vite 开发服务器把它转发给 8080。对浏览器来说，请求一直是同源的。

README 提醒：Vite 代理只在开发时有效，**不会进入 `dist`**。正式部署时，需要在 Nginx 等 Web 服务器上配置同样的转发。

---

## 14.2 Vue 基础：看懂 `.vue` 文件

一个 `.vue` 文件称为**单文件组件**，包含三部分：

```vue
<script setup>
// JavaScript：数据和逻辑
import { ref } from 'vue'
const count = ref(0)
function add() { count.value++ }
</script>

<template>
  <!-- HTML 模板：界面结构 -->
  <button @click="add">点了 {{ count }} 次</button>
</template>

<style>
/* CSS：样式（本项目把样式集中放在 style.css、application.css 中） */
</style>
```

本项目用到的 Vue 概念：

| 概念 | 写法 | 含义 |
| --- | --- | --- |
| 响应式数据 | `ref(0)`、`reactive({...})` | 数据变化时，界面自动更新。`ref` 包装单个值，在 JS 中用 `.value` 访问；`reactive` 包装对象 |
| 计算属性 | `computed(() => ...)` | 由其他数据计算得出，依赖变化时自动重新计算 |
| 侦听 | `watch(source, callback)` | 某个数据变化时执行一段代码 |
| 插值 | `{{ count }}` | 在模板中显示数据 |
| 条件渲染 | `v-if="条件"` / `v-else` | 条件为真才显示 |
| 双向绑定 | `v-model="password"` | 输入框的内容和变量保持同步 |
| 事件 | `@click="add"`、`@submit.prevent="submit"` | 绑定事件处理函数；`.prevent` 阻止表单默认的刷新页面行为 |
| 动态属性 | `:disabled="busy"` | 属性值来自变量（`:` 是 `v-bind:` 的简写） |
| 组件 | `<ConsoleView />` | 使用另一个 `.vue` 文件 |
| 生命周期 | `onMounted(...)`、`onBeforeUnmount(...)` | 组件显示后、销毁前执行 |
| 组合式函数 | `useList(...)`、`useActions()` | 把可复用的逻辑抽成函数，放在 `composables/` 中 |

---

## 14.3 整体结构

```
main.js
 └─ App.vue
     ├─ 未登录：登录页（或 PasswordView 设置/重置密码）
     └─ 已登录：ConsoleView（控制台框架：侧边栏 + 内容区）
          ├─ OverviewView     工作台
          ├─ UsersView        用户账号       需要 IAM_USERS_VIEW
          ├─ RolesView        角色管理       需要 IAM_ROLES_VIEW
          ├─ ResourcesView    应用管理       需要 IAM_RESOURCES_VIEW
          ├─ GrantsView       权限分配       需要 IAM_GRANTS_VIEW
          ├─ OrganizationView 人员与组织变动 需要 IAM_DEPTS_VIEW
          ├─ AdminsView       管理员管理     需要 IAM_ADMINS_VIEW
          └─ AuditView        操作日志       需要 IAM_AUDIT_VIEW
```

[main.js](../frontend/src/main.js) 只有几行：创建 Vue 应用，挂载到 `index.html` 中 `id="app"` 的元素上。

[App.vue](../frontend/src/App.vue) 的模板：

```vue
<template>
  <ConsoleView v-if="session.userId" />      <!-- 已登录：显示控制台 -->
  <div v-else class="login-stage">...</div>   <!-- 未登录：显示登录页 -->
</template>
```

整个前端**没有使用路由库**（如 Vue Router）。页面切换由一个变量 `page` 控制（见 14.6 节）。这也是 README 提到"刷新后重新登录"的原因之一：刷新页面时，所有状态（包括令牌）都丢失了。

---

## 14.4 会话：session.js

### 令牌保存在哪里

```js
export const session = reactive({
  userId: null,
  accountLabel: '',
  menus: [],              // 当前用户在 IAM 应用中的菜单（来自 /auth/menus）
  scope: null,            // 管理资格：是否任命、几级管理员
  accessError: '',
  accessBusy: false,
  accessVersion: 0,       // 权限变化计数器（见下文）
  notice: '',
})
let accessToken = null,   // ★ 令牌：普通的模块变量，不放进 reactive，也不存入 localStorage
  expiryTimer,
  generation = 0,
  accessRequest = null
```

**令牌只保存在内存变量中**，不存入 `localStorage`、`sessionStorage` 或 Cookie。README："JWT 保存在内存，刷新后重新登录。"

为什么不存进 `localStorage`？`localStorage` 中的数据，页面上**任何 JavaScript 代码**都能读取。如果页面存在 XSS 漏洞（攻击者设法在页面中运行了自己的脚本），存在那里的令牌就会被偷走。只放在模块内部的变量里，外部脚本很难拿到。代价是刷新页面后需要重新登录。

`accessToken` 没有放进 `reactive` 的 `session` 对象，也是为了不让它暴露到组件和调试工具中。

### 登录

```js
export async function login(credentials) {
  clearSession()
  const attempt = generation                          // 记下这次登录的"代数"
  const result = await api('/auth/login', { method: 'POST', body: credentials, authenticated: false })
  if (attempt !== generation) return                  // 等待期间又发生了别的登录/退出：放弃这次结果
  if (!result || typeof result.accessToken !== 'string' || result.tokenType !== 'Bearer' || ...)
    throw new ApiError('登录响应不符合接口约定')       // 检查响应格式
  accessToken = result.accessToken
  expiryTimer = setTimeout(() => clearSession('登录已过期，请重新登录'), result.expiresIn * 1000)   // 到期自动退出
  if (!(await refreshAccess())) { ...失败则清除会话... }     // 读取菜单和管理资格
  session.userId = result.userId                       // 设置后，App.vue 切换到控制台
}
```

- **`async` / `await`**：`await` 等待一个异步操作（如网络请求）完成，再继续执行下一行，写法和同步代码一样直观。
- **`generation`（代数）**：每次清除会话时加 1。用户在登录请求返回前点了别的操作（比如又登录了一次），旧请求返回时代数已经变了，结果就被丢弃，防止旧的登录结果覆盖新状态。这个模式在 `session.js` 和 `useList.js` 中反复出现。
- **检查响应格式**：前端不盲目信任后端返回的数据，格式不对就报错。整个前端都有这种检查（`validateMenus`、`pageResult`、`recordId` 等）。

### 读取权限：refreshAccess

```js
const menuResponse = await api('/auth/menus', { query: { appCode } })   // 第 05 课的 ownMenus
const menus = validateMenus(menuResponse, appCode)
let scope = menuResponse.management ?? null                             // { appointed, adminLevel }
if (menus.some((m) => granted(m) && m.menuCode === 'IAM_ADMINS_VIEW')) {
  scope = await api('/admins/me/scope', ...)                            // 第 08 课的 myScope，包含范围根部门
}
if (JSON.stringify([session.menus, session.scope]) !== JSON.stringify([menus, scope]))
  session.accessVersion++                                              // ★ 权限变了，计数器 +1
session.menus = menus
session.scope = scope
```

前端调用的是**和业务系统相同**的 `/auth/menus` 接口（应用编码 `IAM`），得到当前用户在管理后台中的菜单。这就是"自举"在前端的体现：管理后台也作为一个普通应用，接受同一套权限管理。

`??` 是**空值合并运算符**：左边为 `null` 或 `undefined` 时，取右边的值。

### 权限变化时自动刷新：monitorAccess

```js
export function monitorAccess() {
  const refresh = () => { if (!document.hidden) void refreshAccess() }
  window.addEventListener('focus', refresh)                       // 窗口获得焦点时
  document.addEventListener('visibilitychange', refresh)          // 标签页从后台切回时
  const timer = setInterval(refresh, 30_000)                      // 每 30 秒
  ...
}
```

管理员 A 正在使用控制台，管理员 B 收回了 A 的某个功能权限。A 的界面怎样知道？上面三种时机会重新读取菜单。如果菜单有变化，`accessVersion` 加 1，界面随之更新：没有权限的页面从侧边栏消失，按钮隐藏。

`accessVersion` 还有一个用途。[useList.js](../frontend/src/composables/useList.js) 中：

```js
watch(() => session.accessVersion, () => { ...重新加载列表... })
```

权限或管理范围变化后，所有列表自动重新加载。例如管理范围被缩小后，列表中不应再显示范围外的人。

[client.js](../frontend/src/api/client.js) 中也有对应的检查：

```js
if (response.ok && token && method === 'GET' && getAccessVersion() !== accessVersion)
  throw new ApiError('管理权限或范围已变化，请重新查询')
```

一个 GET 请求发出时权限是 A 状态，返回时权限已经变成 B 状态，这次结果可能是按旧权限查出来的，直接丢弃，提示重新查询。

---

## 14.5 统一请求出口：api/client.js

所有组件都通过 `session.js` 导出的 `api(...)` 函数调用后端，没有组件直接使用 `fetch`。统一出口的好处是：令牌、超时、错误处理、格式检查只写一次。

```js
const response = await fetch(`${baseUrl}${path}${params.size ? '?' + params : ''}`, {
  method,
  headers: {
    Accept: 'application/json',
    ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),        // 自动带上令牌
  },
  body: body === undefined ? undefined : JSON.stringify(body),
  signal: controller.signal,                                        // 用于取消和超时
  credentials: 'omit',                                              // 不发送 Cookie
  cache: 'no-store',                                                // 不使用浏览器缓存
  redirect: 'error',                                                // 不跟随重定向
})
```

| 设置 | 原因 |
| --- | --- |
| `Authorization: Bearer ...` | 第 04 课：令牌放在请求头中 |
| `credentials: 'omit'` | 本系统不使用 Cookie 认证；不发 Cookie 可以避免 CSRF 类攻击 |
| `cache: 'no-store'` | 权限数据必须是最新的，不能用浏览器缓存的旧结果 |
| `redirect: 'error'` | API 不应该重定向；出现重定向说明有异常（例如被劫持） |
| 35 秒超时 | `setTimeout(abort, 35_000)`，比后端事务超时（30 秒）略长 |

`...` 是**展开运算符**：`{ ...a, ...b }` 把对象 a 和 b 的属性合并到一个新对象中。`...(条件 ? {x:1} : {})` 是"条件成立才加入某个属性"的常用写法。

### 错误处理

```js
if (response.status === 401 && authenticated) onUnauthorized()   // 401：清除会话，回到登录页
if ([403, 404].includes(response.status) && authenticated && refreshAccessOnError)
  onForbidden()                                                  // 403/404：可能权限变了，刷新菜单
if (!response.ok || payload?.success === false) {
  const messages = {
    OUT_OF_SCOPE: '目标已超出当前管理范围',
    ROLE_NOT_DELEGABLE: '当前角色不在可授权范围内',
    VERSION_CONFLICT: '数据已被其他操作修改',
    INTEGRITY_FAILURE: '服务端完整性验证失败，操作已拒绝',
    ...
  }
  throw new ApiError(messages[payload?.code] || ..., { status, code, requestId })
}
```

这张 `code → 中文提示` 的映射表，对应第 02 课的 `ErrorCode` 枚举。前端按**错误码**而不是按提示文字决定显示什么，后端修改提示文字不会影响前端。

错误信息中会附上 `requestId`（第 02 课 2.6 节），用户报告问题时提供这个编号，开发人员就能在后端日志中找到对应的请求。

`?.` 是**可选链运算符**：`payload?.code` 在 `payload` 为 null 时返回 `undefined`，而不是报错。

### 写操作的网络错误

```js
} catch (error) {
  throw new ApiError(
    method === 'GET' || path === '/auth/login'
      ? '无法连接服务，请确认后端已启动'
      : '未能确认提交结果，请先查询服务端状态；批量操作可用相同内容和请求标识确认，勿重复创建操作',
  )
}
```

读操作失败了，重试即可。**写操作**（授权、修改）如果网络中断，前端**不知道**后端是否已经执行成功（第 11 课 11.8 节"提交确认丢失"）。所以提示用户"先查询状态，不要重复提交"，避免重复授权或重复创建任务。

---

## 14.6 按权限显示：access.js

```js
export const pages = [
  { id: 'users', label: '用户账号', code: 'IAM_USERS_VIEW', path: '/users' },
  { id: 'roles', label: '角色管理', code: 'IAM_ROLES_VIEW', path: '/roles' },
  ...
]
// UI visibility only. Each backend endpoint must independently enforce its permission.
export const can = (code) =>
  !session.accessError &&
  session.menus.some((menu) => menu.menuCode === code && menu.navigationOnly !== true && menu.menuType !== 1)
export const canVisit = (page) => can(page.code)
export const canGlobal = (code) =>
  can(code) && session.scope?.appointed === true && session.scope.adminLevel === 1
```

| 函数 | 判断 | 用途 |
| --- | --- | --- |
| `can(code)` | 当前菜单中有这个编码，且不是"仅导航"的目录 | 显示某个页面或按钮 |
| `canVisit(page)` | `can(page.code)` | 侧边栏显示哪些页面 |
| `canGlobal(code)` | `can(code)` + 是一级管理员 | 资源、角色的修改按钮（第 06、07 课：需要一级管理员） |

`menu.navigationOnly !== true`：第 05 课 5.4 节第 7 步讲过，返回的菜单中包含上级目录，它们被标记为 `navigationOnly`，不代表有权限，这里要排除。

**第一行注释是本课最重要的一句话**：

> UI visibility only. Each backend endpoint must independently enforce its permission.
> （只控制界面显示。每个后端接口必须独立检查权限。）

即使有人修改了浏览器中的 JavaScript，让 `can` 永远返回 true，看到了所有按钮，点击后请求发到后端，仍会被后端的 `requireFunction`、`requireLevelOne`、范围检查拒绝。需求原文："别只做前端灰显——后端 API 鉴权是硬要求，前端只是体验。"

### 控制台：ConsoleView

```js
const views = { users: UsersView, roles: RolesView, ... }
const page = ref('overview')
const available = computed(() => pages.filter(canVisit))      // 有权限的页面
watch(available, (list) => {
  if (page.value !== 'overview' && !list.some((p) => p.id === page.value)) page.value = 'overview'
})                                                            // 当前页面的权限被收回：跳回工作台
```

- 侧边栏只显示 `available` 中的页面。
- 用 `<component :is="views[page]" />` 动态显示当前页面对应的组件。
- 正在查看的页面权限被收回时，自动跳回工作台。

工作区标题也按管理资格显示：一级管理员显示"集团管理空间 · 全集团数据范围"，其他显示"组织管理空间 · 按当前任命范围管理"。

---

## 14.7 一个完整的页面：RolesView

[RolesView.vue](../frontend/src/views/RolesView.vue) 是最短的管理页面之一，适合作为阅读范例：

```js
import { canGlobal as can } from '../access.js'      // 角色管理用 canGlobal：需要一级管理员
const list = useList('/roles'),                       // 加载角色列表
  { dialog, error, notice, busy, perform, saved } = useActions()
const columns = [
  { key: 'roleName', label: '角色名称' },
  { key: 'roleCode', label: '角色编码' },
  { key: 'roleType', label: '角色类型', format: (v) => ({ 1: '业务角色', 2: '管理角色', 3: '超级角色' })[v] },
  { key: 'status', label: '状态' },
]
function create() {
  dialog.value = {
    title: '新建角色',
    fields: [
      ...
      { key: 'roleType', label: '角色类型',
        options: [{ value: 1, label: '业务角色' }, { value: 2, label: '管理角色' }] },   // 没有"超级角色"选项
      ...
    ],
    submit: async (body) => {
      if (!can('IAM_ROLES_WRITE')) throw new Error('当前没有一级管理员配置资格')
      await api('/roles', { method: 'POST', body })
      await list.load()
    },
  }
}
```

前后端对照：

| 前端 | 后端（第 07 课） |
| --- | --- |
| 新建角色的类型选项中没有"超级角色" | `createRole` 中 `roleType == 3` 返回 `BUSINESS_RULE_VIOLATION` |
| `can('IAM_ROLES_WRITE')`（canGlobal） | `requireLevelOneWrite(bearer, "IAM_ROLES_WRITE")` |
| 编辑表单必须填"操作原因" | `UpdateRoleRequest.reason` 为 `@NotBlank` |
| 配置菜单时只列出 `menuType === 2` 的菜单 | `replaceRoleMenus` 中 `menu.getMenuType() != 2` 拒绝 |

前端的这些限制都是为了**体验**：不让用户做注定失败的操作。真正的保证都在后端，前端的每一条限制在后端都有对应的检查。

### 列表加载：useList

```js
const list = useList('/roles')
```

[useList.js](../frontend/src/composables/useList.js) 封装了列表页面的通用逻辑：

- 自动带分页参数 `page` 和 `pageSize=20`；
- 用 `pageResult` 检查响应格式（页码、每页条数必须与请求一致）；
- 发起新请求前，用 `AbortController` 取消上一个未完成的请求，并用 `sequence` 计数器丢弃过时的结果（与 `generation` 同理）；
- `accessVersion` 变化时自动重新加载；
- 组件销毁时取消请求。

返回的 `state` 对象包含 `rows`（数据行）、`total`、`busy`（加载中）、`error`、`load(page)`。页面模板中直接使用这些属性。

`errorText` 函数在 `VERSION_CONFLICT` 时追加提示"请关闭表单，重新读取最新记录后再操作"，对应第 06 课的乐观锁。

---

## 14.8 前端测试

`frontend/tests/` 中的测试使用 **Playwright**：它启动一个真实的浏览器（本机的 Chrome），自动打开页面、输入、点击，检查页面上显示的内容。

[playwright.config.js](../frontend/playwright.config.js) 会同时启动两个开发服务器：

| 端口 | 模式 | 测试文件 | 后端数据从哪来 |
| --- | --- | --- | --- |
| 5175 | 普通模式 | `application.spec.js`、`stage2.spec.js` | 测试代码用 `page.route('**/api/v1/**', ...)` **拦截**浏览器发出的请求，直接返回准备好的响应，可以方便地模拟 401、503 等各种情况 |
| 5176 | 模拟模式 | `stage1.spec.js` | Vite 模拟 API 插件（`dev/mock-api.js`、`dev/fixtures.json`） |

两种方式都不需要真实的后端和数据库。

```sh
npm test         # 运行全部测试
npm run test:ui  # 打开图形界面，可以逐步观看测试过程
```

README 中说明了一个现状："真实页面端到端验收仍待完成。"前端测试都是基于模拟数据的，还没有连接真实后端做完整的端到端测试。

---

## 14.9 本课小结

| 问题 | 答案 |
| --- | --- |
| 令牌存在哪里？为什么？ | 内存中的模块变量；不放 localStorage，降低被 XSS 窃取的风险；代价是刷新后要重新登录 |
| 前端怎样知道当前用户的权限？ | 调用 `/auth/menus?appCode=IAM`，和业务系统用同一个接口 |
| 权限被别人改了，前端怎么知道？ | 窗口聚焦、标签页切回、每 30 秒重新读取；变化时 `accessVersion` +1，列表和菜单自动刷新 |
| 遇到 401 怎么办？ | 清除会话，回到登录页 |
| 遇到 403/404 怎么办？ | 重新读取权限，可能是权限刚被改过 |
| 写操作网络失败怎么提示？ | 提示"先查询状态，勿重复提交"，因为不确定后端是否已执行 |
| `can` 函数能保证安全吗？ | 不能，只控制显示；每个后端接口独立检查权限 |
| 为什么修改角色要用 `canGlobal`？ | 角色修改需要一级管理员，对应后端 `requireLevelOneWrite` |

## 练习

1. 用户在控制台中按 F5 刷新页面，会发生什么？为什么这样设计？
2. 管理员 A 正在"角色管理"页面。管理员 B 收回了 A 的 `IAM_ROLES_VIEW` 权限。A 的页面会怎样变化？最晚多久生效？
3. 有人在浏览器开发者工具中执行代码，把 `session.menus` 改成包含所有菜单，然后点击"新建角色"并提交。会发生什么？
4. 为什么 `client.js` 中要设置 `cache: 'no-store'`？
5. 用户提交授权时网络中断，前端提示"未能确认提交结果"。用户应该怎么做？如果直接再提交一次，可能出现什么情况？（提示：回忆第 07 课的版本号）
6. 二级管理员登录后，侧边栏中能看到"角色管理"吗？能看到"新建角色"按钮吗？（假设他的角色包含 `IAM_ROLES_VIEW` 和 `IAM_ROLES_WRITE`）
7. **动手**：运行 `npm run dev:mock`，用 `admin / 123456` 登录，把每个页面都打开看一遍。然后打开浏览器开发者工具的"网络"面板，观察登录时依次发出了哪些请求。

<details>
<summary>参考答案</summary>

1. 刷新后所有 JavaScript 变量被清空，包括 `accessToken`，用户回到登录页，需要重新登录。这是因为令牌只保存在内存中，没有存入 localStorage。这样设计是为了降低令牌被恶意脚本窃取的风险，用便利性换安全性。
2. 当 A 的窗口获得焦点、标签页从后台切回时，或者最晚 30 秒后，`refreshAccess` 重新读取菜单，发现少了 `IAM_ROLES_VIEW`，`accessVersion` 加 1。`available` 重新计算，侧边栏中"角色管理"消失；`watch(available, ...)` 发现当前页面已不在列表中，跳回工作台。另外，如果 A 在这期间操作了角色页面，后端返回 403，`onForbidden` 也会立即触发刷新。
3. 前端会显示所有按钮，表单也能提交。但请求到达后端 `RoleService.createRole`，第一行 `access.requireLevelOneWrite(bearer, "IAM_ROLES_WRITE")` 会检查：会话、是否一级管理员、是否有 `IAM_ROLES_WRITE`。不满足就返回 403。修改前端数据只能改变显示，无法绕过后端检查。
4. 浏览器可能缓存 GET 请求的结果。如果使用了缓存，权限被修改后，前端读到的可能仍是旧的菜单和列表。`no-store` 要求每次都向服务器请求最新数据，与后端"每次读库、不用缓存"的设计保持一致。
5. 应该先刷新或查询该用户的角色和来源，确认授权是否已经生效。如果直接用同样的内容再提交一次：
   - 第一次已经成功的话，版本号已经变了，第二次带的是旧版本号，后端返回 409 `VERSION_CONFLICT`，不会重复授权；
   - 第一次没有成功的话，第二次正常执行。
   后端的版本号和幂等设计保证了不会产生重复数据，但用户还是应该先查询，弄清楚实际状态。
6. 能看到"角色管理"：`canVisit` 只检查 `can('IAM_ROLES_VIEW')`。看不到（或不能使用）"新建角色"：RolesView 使用 `canGlobal`，要求一级管理员，他是二级。这和后端一致：二级管理员调用 `POST /roles` 会在 `requireLevelOne` 被拒绝。
7. 自己操作。一般会看到：`POST /api/v1/auth/login` → `GET /api/v1/auth/menus?appCode=IAM` → `GET /api/v1/admins/me/scope`（如果有管理员管理权限）→ 工作台需要的列表请求。

</details>

---

上一课：[第 13 课：初始化与兜底恢复](13-初始化与兜底恢复.md)　|　下一课：[第 15 课：测试](15-测试.md)
